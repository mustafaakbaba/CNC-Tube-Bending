import numpy as np
import math

ANGLE_TOLERANCE = 0.01
DISTANCE_TOLERANCE = 0.01
FIXED_VECTOR = (1, 1, 1) # It will be used for determining the sign of the angle of rotation and bend


def read_file(filename):
    with open(filename, 'r') as f:
        data = f.read()
    return data


def get_points(line) -> tuple:
    p, x, y, z = [line[0:5], line[5:22], line[22:39], line[39:56]]
    return float(x), float(y), float(z)


def calculate_distance(x1, y1, z1, x2, y2, z2) -> float:
    distance = ((x1-x2)**2 + (y1-y2)**2 + (z1-z2)**2)**(1/2)
    if distance > DISTANCE_TOLERANCE:
        return distance
    else:
        return 0


def unit_vector(v):
    """ Returns the unit vector of the vector.  """
    try:
        return v / norm(v)
    except:
        return v

def norm(v : list):
    """ Returns norm of vector) """
    return np.linalg.norm(v)

def calculate_clockwise_angle(v1, v2, u) -> float:
    """ Returns the angle in radians between vectors 'v1' and 'v2'::

            >>> angle_between((1, 0, 0), (0, 1, 0))
            1.5707963267948966
            >>> angle_between((1, 0, 0), (1, 0, 0))
            0.0
            >>> angle_between((1, 0, 0), (-1, 0, 0))
            3.141592653589793
    """
    #print("Tripe Product:", triple_product(v1, v2, u))
    if triple_product(v1, v2, u) > 0:
        angle = calculate_angle(v1, v2)
        return angle
    else:
        angle = -calculate_angle(v1, v2)
        return angle


def triple_product(v1, v2, u):
    """ Returns triple product of as v1 x v2 . u """
    r = np.dot(u, np.cross(v1, v2))
    return r

def calculate_angle(v1, v2) -> float:
    """ Returns the angle in radians between vectors 'v1' and 'v2'::

            >>> angle_between((1, 0, 0), (0, 1, 0))
            1.5707963267948966
            >>> angle_between((1, 0, 0), (1, 0, 0))
            0.0
            >>> angle_between((1, 0, 0), (-1, 0, 0))
            3.141592653589793
    """
    v1_u = unit_vector(v1)
    v2_u = unit_vector(v2)
    angle = np.arccos(np.clip(np.dot(v1_u, v2_u), -1.0, 1.0))
    
    if abs(angle) > ANGLE_TOLERANCE:
        return angle % math.pi
    else:
        return 0
    #return math.degrees(np.arcsin( norm( np.cross( v1, v2 ) ) / ( norm(v1) * norm(v2) ) ))

def vectorize(x1, y1, z1, x2, y2, z2) -> list:
    vx = x2 - x1
    vy = y2 - y1
    vz = z2 - z1
    return (vx, vy, vz)

def normal_vector(x1, y1, z1, x2, y2, z2, x3, y3, z3):
    ux, uy, uz = u = vectorize(x1, y1, z1, x2, y2, z2)
    vx, vy, vz = v = vectorize(x2, y2, z2, x3, y3, z3)
    
    u_cross_v = [uy*vz-uz*vy, uz*vx-ux*vz, ux*vy-uy*vx]
    
    return u_cross_v

def find_corrected_bend_angle(bend_angle):

    #bend_angle_in_degree = math.degrees(bend_angle)

   #return bend_angle
    """
    y = 2E-05x3 - 0.0047x2 + 1.0732x + 77.12
    """
   
    if abs(bend_angle) >= 1*(math.pi/180):
        if bend_angle > 0:
            bend_angle_in_degree = math.degrees(bend_angle)
            return bend_angle_in_degree
        else:
            bend_angle = -bend_angle
            bend_angle_in_degree = math.degrees(bend_angle)
            return -1*bend_angle_in_degree
    else:
        return 0

def generate_gcode_from_points(points_file_name, gcode_file_name, feed2):
    last_bended_plane_normal_vector = (0, 0, 1)

    data = read_file(points_file_name)
    points_list = data.split('\n')
    commands = []
    label = 1

    # When i = 1
    raw_points_1 = points_list[0]
    raw_points_2 = points_list[1]
    x1, y1, z1 = get_points(raw_points_1)
    x2, y2, z2 = get_points(raw_points_2)
    feed = calculate_distance(x1, y1, z1, x2, y2, z2)
    if feed !=0:
        commands += [["G01 Y", str(feed2)]]


    # When i = 2
    raw_points_1 = points_list[0]
    raw_points_2 = points_list[1]
    raw_points_3 = points_list[2]
    x1, y1, z1 = get_points(raw_points_1)
    x2, y2, z2 = get_points(raw_points_2)
    x3, y3, z3 = get_points(raw_points_3)
    normal_vector_1 = normal_vector(x1, y1, z1, x2, y2, z2, x3, y3, z3)
    vector_1 = vectorize(x1, y1, z1, x2, y2, z2)
    vector_2 = vectorize(x2, y2, z2, x3, y3, z3)
    bend_angle = calculate_clockwise_angle(vector_1, vector_2, FIXED_VECTOR)
    bend_angle = find_corrected_bend_angle(bend_angle)
    feed = calculate_distance(x2, y2, z2, x3, y3, z3)
    if bend_angle != 0:
        last_bended_plane_normal_vector = normal_vector_1
#        print("Bend Angle:", math.degrees(bend_angle))
        if bend_angle * label < 0:
            label = -label
            if commands[-1][0] == "G01 B":
                commands[-1][1] = str(float(commands[-1][1]) + label * 180)
            else:
                commands += [["G01 B", str(180 * label)]]
            commands += [["G01 C", str(abs(bend_angle))]]
        else:
            commands += [["G01 C", str(abs(bend_angle))]]
    if feed != 0:
        if commands[-1][0] == "G01 Y":
            commands[-1][1] = str(float(commands[-1][1])+feed2)
        else:
            commands += [["G01 Y", str(feed2)]]

    # When i > 2
    for i in range(3, len(points_list)):
        if not points_list[i]:
            break
        raw_points_1 = points_list[i-3]
        raw_points_2 = points_list[i-2]
        raw_points_3 = points_list[i-1]
        raw_points_4 = points_list[i]
        x1, y1, z1 = get_points(raw_points_1)
        x2, y2, z2 = get_points(raw_points_2)
        x3, y3, z3 = get_points(raw_points_3)
        x4, y4, z4 = get_points(raw_points_4)
        # Find vector which i-2th, i-1th points generate
        vector_1 = vectorize(x2, y2, z2, x3, y3, z3)
        # Find vector which i-1th, ith points generate
        vector_2 = vectorize(x3, y3, z3, x4, y4, z4)
        # Find angle between two vectors
        bend_angle = calculate_clockwise_angle(vector_1, vector_2, FIXED_VECTOR)
#        print("Raw Bend Angle:", bend_angle)
        bend_angle = find_corrected_bend_angle(bend_angle)
#        print("Corrected Bend Angle:", bend_angle)
        feed = calculate_distance(x3, y3, z3, x4, y4, z4)
        if bend_angle != 0:
            # Find normal vector of plane which i-3th, i-2th, i-1th points span
            normal_vector_1 = normal_vector(x1, y1, z1, x2, y2, z2, x3, y3, z3)
            # Find normal vector of plane which i-2th, i-1th, ith points span
            normal_vector_2 = normal_vector(x2, y2, z2, x3, y3, z3, x4, y4, z4)
            # Calculate the angle between two planes' normal vectors
            rotate_angle = calculate_angle(last_bended_plane_normal_vector, normal_vector_2)
            rotate_angle = math.degrees(rotate_angle)
            print(rotate_angle)
            print(bend_angle)
            print("------")
            if rotate_angle > 0:
#                print("Rotate Angle in Degree:", math.degrees(rotate_angle))
#                if rotate_angle == 180:
#                    print("Vectors:", normal_vector_1, normal_vector_2)
                commands += [["G01 B", str(-1*rotate_angle)]]
            if rotate_angle < 0:
                commands += [["G01 B", str(rotate_angle)]]
        if bend_angle != 0:
            last_bended_plane_normal_vector = normal_vector_2
#            print("Bend Angle in Degree:", math.degrees(bend_angle))
            if bend_angle*label < 0:
                label = -label
                if commands[-1][0] == "G01 B":
                    if float(commands[-1][1]) + label * 180<-180:
                        commands[-1][1] = str(float(commands[-1][1]) + label * 180+360)
                    else:
                        commands[-1][1] = str(float(commands[-1][1]) + label * 180)
                else:
                    commands += [["G01 B", str(180*label)]]
                commands += [["G01 C", str(abs(bend_angle))]]
            else:
                commands += [["G01 C", str(abs(bend_angle))]]

        if feed != 0:
            if commands[-1][0] == "G01 Y":
                commands[-1][1] = str(float(commands[-1][1])+feed2)
            else:
                commands += [["G01 Y", str(feed2)]]
#        print("-------------------------------------")
            
    with open(gcode_file_name, "w+") as f:
        for command in commands:
            f.write(''.join(command) + "\n")
    try:
        with open(str(gcode_file_name).split('.', 1)[0]+'_arduino.'+str(gcode_file_name).split('.', 1)[1], "w+") as f:
            for command in commands:
                command[0] = command[0].replace(" ", "")
                f.write(' '.join(command) + "\n")
    except:
        with open(str(gcode_file_name)+'_arduino.', "w+") as f:
            for command in commands:
                command[0] = command[0].replace(" ", "")
                f.write(' '.join(command) + "\n")
    return commands


