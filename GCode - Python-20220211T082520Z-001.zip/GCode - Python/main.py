import convert
from gcode_generator import generate_gcode_from_points
from GUI import screen, screen2
import os
import sys

try:
    locs = screen()
except:
    sys.exit()
igs_file_name = locs[0]
igs_file_name = igs_file_name.strip()
if not os.path.isfile(igs_file_name):
    print("IGS file '%s' does not exist" % igs_file_name)
    sys.exit()
'''
points_file_name = input('Name of the output points file (Default "data.txt"): ')
points_file_name = points_file_name.strip()
if not points_file_name:
    points_file_name = "data.txt"
'''

gcode_file_name = locs[1]
gcode_file_name = gcode_file_name.strip()
points_file_name = "data.txt"
feed2 = 9.6
convert.convert(igs_file_name, points_file_name)
generate_gcode_from_points(points_file_name, gcode_file_name, feed2)

screen2(gcode_file_name)
