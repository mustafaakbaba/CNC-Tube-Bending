def convert(igs_file_name, output_file_name="data.txt"):
    IGS = open(igs_file_name,'r')
    igs = IGS.read().splitlines()

    for i in range(len(igs)): # Psiz satırları çıkar
        if(igs[0][72]=='P'):
            break
        else:
            igs.pop(0)

    igs=igs[:-1] # Son satırı çıkar

    for i in range(len(igs)): # En sondaki #P # kısımlarını çıkar
        j = igs[i].rfind(';')
        if(j==-1):
            j= igs[i].rfind(',')
        igs[i] = igs[i][:j+1]
        igs[i] = igs[i].replace(' ','')


    igsn = '' # Tüm satırları tek stringte topla
    for i in range(len(igs)):
        igsn = igsn+igs[i]
    igsn = igsn.replace(';','\n')
    igsn = igsn.split('\n') # Satırları doğru yerlerden tekrar ayır

    points = []
    igsf = [] # 100 ve 110'la başlayan satırları finalde topla
    for i in range(len(igsn)):
        igsi = igsn[i].split(',')
        if(igsi[0]=='116'):
            igsf.append(igsn[i])
            mem = []
            for j in range(1,4,1):
                mem.append(float(igsi[j]))
            points.append(mem)
            continue
#    print(points)
    t=1
    for i in range(len(igsf)): # Şeklini ver ve gereksiz satırları çıkar
        if(igsf[i][:3]=='116'):
            igsf[i]='P{:03d} {:16.11f} {:16.11f} {:16.11f}'.format(t,points[i][0],points[i][1],points[i][2])
        igsf[i] = igsf[i].replace(',', ' ')
        t=t+1

    f = open(output_file_name, "w")

    # Satırları tersine çevir
    igsf.reverse()
    for i in range(len(igsf)):
        f.write(igsf[i])
        f.write('\n')

    f.close()
    IGS.close()

    return(igsf)







