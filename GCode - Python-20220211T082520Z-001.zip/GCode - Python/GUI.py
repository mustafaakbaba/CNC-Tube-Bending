import tkinter as tk
from tkinter import *
from tkinter import ttk
from tkinter import filedialog as fd
from tkinter.messagebox import showinfo
from tkinterdnd2 import DND_FILES, TkinterDnD
from pathlib import Path

def screen2(loc_name):

    root = Tk()
    root.title('G-Code')
    root.resizable(False, False)
    root.geometry('225x500+600+150')
    GCode = open(loc_name, 'r')
    gcode = GCode.read()
    icon = PhotoImage(file="C:/Users/CASPER/Desktop/pythonProject1 - Kopya/dene.png")
    root.iconphoto(False, icon)
    text = Text(root, width=50, height=30)

    # Insert the text at the begining
    text.insert(INSERT, gcode)
    text.pack(expand=1, fill=BOTH)

    root.mainloop()

def screen():
    global filename, root, seltxt, loctxt, locname

    # create the root window
    root = Tk()
    label = Label(root,text="IGS to G-Code" ,font=("Times New Roman", 23))
    label.place(relx=0.5, rely=0.2, anchor=CENTER)
    root.title('IGS to G-Code')
    root.resizable(False, False)
    root.geometry('500x200+600+150')
    rootHeight = root.winfo_height()
    rootWidth = root.winfo_width()

    icon = PhotoImage(file="C:/Users/CASPER/Desktop/pythonProject1 - Kopya/dene.png")
    root.iconphoto(False, icon)

    locname = str(Path().absolute())+'\gcode.txt'
    def select_file():
        global filename, seltxt
        filetypes = (
            ('IGS files', '*.igs'),
            ('All files', '*.*')
        )

        filename_i = fd.askopenfilename(
            title='Open a file',
            initialdir='/Desktop',
            filetypes=filetypes)
        if filename_i == '':
            showinfo(
                title='Warning!',
                message='Nothing is selected!'
            )
        else:
            filename = filename_i
            '''
            showinfo(
                title='Selected File',
                message=filename
            )
            '''
            seltxt.config(state='normal')
            seltxt.delete(1.0, "end")
            seltxt.insert(INSERT, filename)
            seltxt.config(state='disabled')

    def select_loc():
        global locname, loctxt
        filetypes = (
            ('Text files', '*.txt'),
            ('All files', '*.*')
        )
        locname_i = fd.asksaveasfilename(
            title='Save as',
            initialdir='/Desktop',
            filetypes=filetypes)
        if locname_i == '':
            showinfo(
                title='Warning!',
                message='Nothing is selected!'
            )
        else:
            locname = locname_i
            '''
            showinfo(
                title='Save as',
                message=locname
            )
            '''
            loctxt.config(state='normal')
            loctxt.delete(1.0, "end")
            loctxt.insert(INSERT, locname)
            loctxt.config(state='disabled')

    seltxt = Text(root, height=1, width=rootWidth*45)
    seltxt.place(relx=0.44, rely=0.45, anchor=CENTER)
    seltxt.config(state='disabled')

    loctxt = Text(root, height=1, width=rootWidth*45)
    loctxt.place(relx=0.44, rely=0.6, anchor=CENTER)

    loctxt.insert(INSERT, str(Path().absolute()).replace('\\','/')+'/gcode.txt')
    loctxt.config(state='disabled')



    # open button
    open_button = ttk.Button(
        root,
        text='Open a File',
        command=select_file
    )
    open_button.place(relx=0.88,rely=0.45, anchor=CENTER)
    save_loc = ttk.Button(
        root,
        text='Save file',
        command=select_loc
    )
    save_loc.place(relx=0.88, rely=0.6, anchor=CENTER)
    def close():
        global root, filename
        try:
            filename
            root.destroy()
        except:
            showinfo(
                title='Warning!',
                message='Select a file!'
            )


    okbut = ttk.Button(root, text="OK", command=close)
    okbut.place(relx=0.5, rely=0.85, anchor=CENTER)

    root.mainloop()
    return filename, locname
